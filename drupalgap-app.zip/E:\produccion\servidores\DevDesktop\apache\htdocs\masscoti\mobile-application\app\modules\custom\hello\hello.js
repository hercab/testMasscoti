/**
 * Implements hook_menu().
 */
function hello_menu() {
  var items = {};
  items['hello_world'] = {
    title: 'DrupalGap',
    page_callback: 'hello_hello_world_page'
  };
  return items;
}

/**
 * The callback for the "Hello World" page.
 */
function hello_hello_world_page() {
  var content = {};
  content['my_button'] = {
    theme: 'button',
    text: 'Hello World',
    attributes: {
      onclick: "drupalgap_alert('Hi!')"
    }
  };
  return content;
}