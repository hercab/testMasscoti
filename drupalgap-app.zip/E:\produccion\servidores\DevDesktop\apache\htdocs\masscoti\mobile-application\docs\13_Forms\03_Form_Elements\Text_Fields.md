Also, checkout the [Text Widget](../../Widgets/Text_Widget) page.

![Text Field Widget](http://drupalgap.org/sites/default/files/textfield-widget.png)

```
form.elements['my_textfield'] = {
  title: 'Name',
  type: 'textfield',
  default_value: 'Hello'
};
```