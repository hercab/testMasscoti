To simulate our Geo Location inside of Ripple, we can use [Google Maps](https://maps.google.com).

**1.** [Obtain the Latitude and Longitude coordinates](Get_Latitude_and_Longitude_with_Google_Maps) you'd like to simulate.

**2.** In Ripple, expand the **Geo Location** sidebar menu and copy/paste the latitude and longitude coordinates obtained earlier:

![Ripple Geo Location](http://www.drupalgap.org/sites/default/files/ripple-geo-location-lat-long.png)

**3.** Done!

That's it, now just use your app to test out your simulated location.